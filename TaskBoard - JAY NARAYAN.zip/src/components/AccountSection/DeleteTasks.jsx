import React, { useState } from "react";
import { useAppDispatch } from "../../store/hooks";
import { tasksActions } from "../../store/Tasks.store";
import ModalConfirm from "../Utilities/ModalConfirm";

const DeleteTasks = () => {
  const dispatch = useAppDispatch();

  const [showModal, setIsModalShown] = useState(false);

  const deleteAllDataHandler = () => {
    dispatch(tasksActions.deleteAllData());
  };

  return React.createElement(
    React.Fragment,
    null,
    showModal && React.createElement(ModalConfirm, {
      onClose: () => setIsModalShown(false),
      text: "All data will be deleted permanently.",
      onConfirm: deleteAllDataHandler
    }),
    React.createElement("button", {
      className: "mt-auto text-left pt-4 hover:text-rose-600 dark:hover:text-slate-200 transition",
      onClick: () => setIsModalShown(true)
    }, "Delete all data")
  );
};

export default React.memo(DeleteTasks);
