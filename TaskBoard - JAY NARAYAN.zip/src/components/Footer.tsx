import React from "react";

const Footer: React.FC = () => {
  return <footer className="text-center py-6 font-medium">Copyright @2024 TASK BOARD</footer>;
};

export default Footer;
