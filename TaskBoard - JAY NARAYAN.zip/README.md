
📅 Task Board App (To-Do List)
Website for a task organizer (to-do list) made with React JS, Tailwind CSS, JavaScript, Redux Toolkit, and more.

Home page

Description!!

Application to organize your tasks with the following data: title, description, date, mark as complete, and mark as important.
Tasks are organized into routes: today's tasks, important tasks, incomplete tasks, complete tasks, all tasks, and tasks by directory (folder). Directories and tasks can be edited or deleted. Additionally, there is a main directory called "Main" that cannot be edited or deleted.
The task list can be displayed first by: nearest, farthest, complete, or incomplete.
You can search for any tasks in the search field.
Today's tasks are displayed in the user section and notifications.
Task, directory, and dark mode data are saved in localStorage.
Objective
The project mainly aimed to put into practice knowledge of TypeScript, Tailwind, Redux Toolkit, and React Js.

Tools used
React JS
JavaScript
TypeScript
Tailwind CSS
Redux Toolkit
React Router DOM
HTML
How to test
You can access the project here: https://jay-taskboard-a8768f.netlify.app/

Or run it on your machine:

bash
Copy code
git clone https://github.com/jaynarayan91/
cd tasks-app
npm install
npm start
Notes
Task, directory, and dark mode data are saved in the localStorage of your browser. You can click the "delete all data" button to remove them from localStorage.
For demonstration purposes, the application has a default list of 3 tasks and 1 directory named "Main".